================================================================================
STI COLLEGE ALABANG - DEPARTMENT OF INFORMATION TECHNOLOGY EDUCATION
03 LABORATORY EXERCISE 1: PYGAME AND OPENGL (WIREFRAME CUBE)
================================================================================
Student Name:     Godwyn Neri
Course / Code:    Game Development / Computer Graphics Programming (IT2202)
Program / Section: BSIT / BSIT711
Term & Year:      Midterm, SY 2026-2027 1T
Date Submitted:   September 22, 2026

DELIVERABLES MANIFEST:
--------------------------------------------------------------------------------
1. 03_Laboratory_Exercise_1_Godwyn_Neri_BSIT711.pdf
   - Complete 8-page academic submission report adhering to STI standards.
   - Includes geometric topologies, 3D math pipeline, and verified execution figures.

2. 03_Laboratory_Exercise_1_Godwyn_Neri_BSIT711.mp4
   - 60 FPS H.264 video demonstration of the rotating wireframe cube.
   - 6.0 seconds duration (360 frames = full 360-degree rotation across axis (1,1,1)).
   - Features embedded student HUD (Godwyn Neri, BSIT711, angle telemetry).

3. 03_Laboratory_Exercise_1_Godwyn_Neri_BSIT711.py
   - Standalone, executable Python script conforming to all 19 procedural steps.

4. 03_Laboratory_Exercise_1_Godwyn_Neri_BSIT711.docx
   - Editable Microsoft Word submission document with STI corporate styling.
================================================================================
